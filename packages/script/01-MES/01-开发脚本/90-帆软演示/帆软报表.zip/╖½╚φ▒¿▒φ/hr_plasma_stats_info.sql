/*
 Navicat Premium Data Transfer

 Source Server         : 160
 Source Server Type    : MySQL
 Source Server Version : 80036
 Source Host           : 172.30.1.160:3306
 Source Schema         : bmos_mes

 Target Server Type    : MySQL
 Target Server Version : 80036
 File Encoding         : 65001

 Date: 17/04/2024 15:19:26
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for hr_plasma_stats_info
-- ----------------------------
DROP TABLE IF EXISTS `hr_plasma_stats_info`;
CREATE TABLE `hr_plasma_stats_info`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `stats_time` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '统计时间',
  `plasma_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '投浆量',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `create_time` datetime NULL DEFAULT NULL,
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `update_time` datetime NULL DEFAULT NULL,
  `is_deleted` tinyint(1) NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '血浆投浆量年份数量' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of hr_plasma_stats_info
-- ----------------------------
INSERT INTO `hr_plasma_stats_info` VALUES (1, '2020', '5750', '1', '2024-04-17 11:12:14', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_info` VALUES (2, '2021', '5900', '1', '2024-04-17 11:12:14', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_info` VALUES (3, '2022', '5324', '1', '2024-04-17 11:12:14', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_info` VALUES (4, '2023', '6540', '1', '2024-04-17 11:12:14', NULL, NULL, 0);

SET FOREIGN_KEY_CHECKS = 1;
