/*
 Navicat Premium Data Transfer

 Source Server         : 160
 Source Server Type    : MySQL
 Source Server Version : 80036
 Source Host           : 172.30.1.160:3306
 Source Schema         : bmos_mes

 Target Server Type    : MySQL
 Target Server Version : 80036
 File Encoding         : 65001

 Date: 17/04/2024 15:19:40
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for hr_product_stats_info
-- ----------------------------
DROP TABLE IF EXISTS `hr_product_stats_info`;
CREATE TABLE `hr_product_stats_info`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `product_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '产品名称',
  `stats_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '统计数量',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `create_time` datetime NULL DEFAULT NULL,
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `update_time` datetime NULL DEFAULT NULL,
  `is_deleted` tinyint(1) NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = ' 在库成品数量' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of hr_product_stats_info
-- ----------------------------
INSERT INTO `hr_product_stats_info` VALUES (1, '人血白蛋白', '900', '1', '2024-04-17 11:27:01', NULL, NULL, 0);
INSERT INTO `hr_product_stats_info` VALUES (2, 'PCC', '1000', '1', '2024-04-17 11:27:01', NULL, NULL, 0);
INSERT INTO `hr_product_stats_info` VALUES (3, 'Ⅷ因子', '800', '1', '2024-04-17 11:27:01', NULL, NULL, 0);

SET FOREIGN_KEY_CHECKS = 1;
