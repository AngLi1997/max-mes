/*
 Navicat Premium Data Transfer

 Source Server         : 160
 Source Server Type    : MySQL
 Source Server Version : 80036
 Source Host           : 172.30.1.160:3306
 Source Schema         : bmos_mes

 Target Server Type    : MySQL
 Target Server Version : 80036
 File Encoding         : 65001

 Date: 17/04/2024 15:19:33
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for hr_plasma_stats_item
-- ----------------------------
DROP TABLE IF EXISTS `hr_plasma_stats_item`;
CREATE TABLE `hr_plasma_stats_item`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `stats time` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '统计时间',
  `plasma_month_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '统计数量',
  `plasma_id` bigint NOT NULL COMMENT '年份表id',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `create_time` datetime NULL DEFAULT NULL,
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `update_time` datetime NULL DEFAULT NULL,
  `is_deleted` tinyint(1) NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 49 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '月份投浆分布' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of hr_plasma_stats_item
-- ----------------------------
INSERT INTO `hr_plasma_stats_item` VALUES (1, '1', '300', 1, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (2, '2', '500', 1, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (3, '3', '600', 1, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (4, '4', '500', 1, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (5, '5', '200', 1, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (6, '6', '800', 1, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (7, '7', '350', 1, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (8, '8', '400', 1, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (9, '9', '100', 1, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (10, '10', '600', 1, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (11, '11', '800', 1, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (12, '12', '600', 1, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (13, '1', '400', 2, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (14, '2', '500', 2, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (15, '3', '800', 2, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (16, '4', '150', 2, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (17, '5', '600', 2, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (18, '6', '650', 2, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (19, '7', '300', 2, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (20, '8', '400', 2, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (21, '9', '100', 2, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (22, '10', '600', 2, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (23, '11', '800', 2, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (24, '12', '600', 2, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (25, '1', '600', 3, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (26, '2', '550', 3, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (27, '3', '600', 3, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (28, '4', '450', 3, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (29, '5', '200', 3, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (30, '6', '300', 3, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (31, '7', '320', 3, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (32, '8', '622', 3, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (33, '9', '426', 3, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (34, '10', '777', 3, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (35, '11', '123', 3, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (36, '12', '356', 3, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (37, '1', '600', 4, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (38, '2', '550', 4, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (39, '3', '600', 4, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (40, '4', '450', 4, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (41, '5', '200', 4, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (42, '6', '666', 4, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (43, '7', '420', 4, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (44, '8', '622', 4, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (45, '9', '426', 4, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (46, '10', '900', 4, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (47, '11', '650', 4, '1', '2024-04-17 11:14:09', NULL, NULL, 0);
INSERT INTO `hr_plasma_stats_item` VALUES (48, '12', '456', 4, '1', '2024-04-17 11:14:09', NULL, NULL, 0);

SET FOREIGN_KEY_CHECKS = 1;
