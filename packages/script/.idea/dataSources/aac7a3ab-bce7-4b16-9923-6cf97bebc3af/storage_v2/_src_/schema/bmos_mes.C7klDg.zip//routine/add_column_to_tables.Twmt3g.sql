create
    definer = root@`%` procedure add_column_to_tables()
BEGIN
    DECLARE i INT DEFAULT 0;
    WHILE i < 100 DO
        SET @table_name = CONCAT('bm_execute_form_data_', i);
        SET @sql = CONCAT('ALTER TABLE ', @table_name,' ADD procedure_step_model_id bigint DEFAULT NULL COMMENT ''工步模型id'';');
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
        SET i = i + 1;
    END WHILE;
END;

