create
    definer = root@`%` procedure insertData()
BEGIN
    DECLARE i INT DEFAULT 0;
    WHILE i < 100 DO 
    INSERT INTO bm_procedure VALUES (CONV(SUBSTRING(uuid(), 1, 8), 16, 10), CONV(SUBSTRING(uuid(), 1, 8), 16, 10), uuid()); 
    SET i = i + 1;
        END WHILE;
END;

